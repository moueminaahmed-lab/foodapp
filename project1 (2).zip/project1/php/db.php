<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

$conn = new mysqli(
  "fdb1032.awardspace.net",
  "4718774_foodprojectdb",
  "Fooddb2025@",
  "4718774_foodprojectdb"
);

if ($conn->connect_error) {
  echo json_encode([
    "status" => "error",
    "message" => "DB connection failed"
  ]);
  exit;
}

echo json_encode(["status"=>"ok"]);
?>