<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");include "db.php";

$data = json_decode(file_get_contents("php://input"), true);

$email = $data["email"] ?? "";
$password = $data["password"] ?? "";

if ($email=="" || $password=="") {
  echo json_encode([
    "status"=>"error",
    "message"=>"Email and Password are required"
  ]);
  exit;
}

$sql = "SELECT goal FROM Users WHERE email='$email' AND password='$password'";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
  $row = $result->fetch_assoc();
  echo json_encode([
    "status"=>"success",
    "goal"=>$row["goal"]
  ]);
} else {
  echo json_encode([
    "status"=>"error",
    "message"=>"Invalid login"
  ]);
}

$conn->close();
?>