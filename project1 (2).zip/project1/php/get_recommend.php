<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
include "db.php";

$input = json_decode(file_get_contents("php://input"), true);
$goal = $input["goal"] ?? "";

if ($goal=="") {
  echo json_encode(["status"=>"error","message"=>"Goal required"]);
  exit;
}

if ($goal == "gain") {
  $food = "food_gain";
  $pic = "foodgain_picture";
} else {
  $food = "food_lose";
  $pic = "foodlose_picture";
}

$sql = "SELECT name_c, $food AS food_name, $pic AS food_image FROM Country";
$result = $conn->query($sql);

$data = [];
while ($row = $result->fetch_assoc()) {
  $data[] = $row;
}

echo json_encode([
  "status"=>"success",
  "foods"=>$data
]);

$conn->close();
?>
