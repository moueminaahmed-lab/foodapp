<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");include "db.php";

$input = json_decode(file_get_contents("php://input"), true);

$name = $input["name_u"] ?? "";
$email = $input["email"] ?? "";
$password = $input["password"] ?? "";
$goal = $input["goal"] ?? "";

if ($name=="" || $email=="" || $password=="" || $goal=="") {
  echo json_encode(["status"=>"error","message"=>"All fields required"]);
  exit;
}

$sql = "INSERT INTO Users (name_u,email,password,goal)
        VALUES ('$name','$email','$password','$goal')";

if ($conn->query($sql)) {
  echo json_encode(["status"=>"success"]);
} else {
  echo json_encode(["status"=>"error","message"=>"Insert failed"]);
}

$conn->close();
?>