import 'package:flutter/material.dart';
import 'food.dart';

class UserPage extends StatelessWidget {
  final String goal;

  const UserPage({super.key, required this.goal});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('User Goal'), centerTitle: true),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              goal == 'gain' ? 'Goal: Gain Weight' : 'Goal: Lose Weight',
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => FoodPage(goal: goal),
                  ),
                );
              },
              child: const Text('Show Recommended Food'),
            ),
          ],
        ),
      ),
    );
  }
}