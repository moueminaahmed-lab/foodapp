import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class FoodItem {
  String country;
  String foodName;
  String foodImage;

  FoodItem({required this.country, required this.foodName, required this.foodImage});
}

class FoodPage extends StatefulWidget {
  final String goal;

  const FoodPage({super.key, required this.goal});

  @override
  State<FoodPage> createState() => _FoodPageState();
}

class _FoodPageState extends State<FoodPage> {
  List<FoodItem> foods = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchFoods();
  }

  Future<void> fetchFoods() async {
    setState(() { isLoading = true; });

    final url = Uri.parse('https://foodproject2025.atwebpages.com/get_recommend.php');
    try {
      final response = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"goal": widget.goal}),
      );

      final data = jsonDecode(response.body);
      if (data['status'] == 'success') {
        final List<FoodItem> loaded = [];
        for (var f in data['foods']) {
          loaded.add(FoodItem(
            country: f['name_c'],
            foodName: f['food_name'],
            foodImage: f['food_image'],
          ));
        }
        setState(() {
          foods = loaded;
        });
      } else {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(data['message'])));
      }
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Server error')));
    }

    setState(() { isLoading = false; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Foods - ${widget.goal}'), centerTitle: true),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
        itemCount: foods.length,
        itemBuilder: (context, index) {
          final f = foods[index];
          return Card(
            margin: const EdgeInsets.all(10),
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                children: [
                  Text(
                    f.country,
                    style: const TextStyle(
                        fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 5),

                  Image.asset(
                    'assets/${f.foodImage}',
                    width: 150,
                    height: 150,
                    fit: BoxFit.cover,
                  ),
                  const SizedBox(height: 5),
                  Text(
                    f.foodName,
                    style: const TextStyle(fontSize: 16),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
