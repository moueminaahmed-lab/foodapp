import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'welcome.dart';

class SignUpPage extends StatefulWidget {
  const SignUpPage({super.key});

  @override
  State<SignUpPage> createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  String goal = 'gain';
  bool isLoading = false;

  Future<void> signUp() async {
    if(nameController.text.isEmpty || emailController.text.isEmpty || passwordController.text.isEmpty){
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('All fields are required')));
      return;
    }

    setState(() { isLoading = true; });

    final url = Uri.parse('https://foodproject2025.atwebpages.com/signup.php');
    final response = await http.post(url,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "name_u": nameController.text,
          "email": emailController.text,
          "password": passwordController.text,
          "goal": goal
        })
    );

    final data = jsonDecode(response.body);

    setState(() { isLoading = false; });

    if(data['status'] == 'success'){
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('User registered successfully')));
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const WelcomePage()));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(data['message'])));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sign Up'), centerTitle: true),
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              MyTextField(controller: nameController, hint: 'Name'),
              const SizedBox(height: 10),
              MyTextField(controller: emailController, hint: 'Email'),
              const SizedBox(height: 10),
              MyTextField(controller: passwordController, hint: 'Password', obscure: true),
              const SizedBox(height: 10),
              DropdownButton<String>(
                value: goal,
                items: const [
                  DropdownMenuItem(value: 'gain', child: Text('Gain Weight')),
                  DropdownMenuItem(value: 'lose', child: Text('Lose Weight')),
                ],
                onChanged: (val){
                  setState(() { goal = val!; });
                },
              ),
              const SizedBox(height: 20),
              isLoading
                  ? const CircularProgressIndicator()
                  : ElevatedButton(
                onPressed: signUp,
                child: const Text('Save'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class MyTextField extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final bool obscure;

  const MyTextField({super.key, required this.controller, required this.hint, this.obscure=false});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 250,
      height: 50,
      child: TextField(
        controller: controller,
        obscureText: obscure,
        decoration: InputDecoration(
          border: const OutlineInputBorder(),
          hintText: hint,
        ),
      ),
    );
  }
}
