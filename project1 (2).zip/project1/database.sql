CREATE TABLE Users (
  id_u INT PRIMARY KEY AUTO_INCREMENT,
  name_u VARCHAR(50),
  email VARCHAR(50),
  password VARCHAR(50),
  goal VARCHAR(10)
);

INSERT INTO Users (name_u, email, password, goal) VALUES
('Mouemima','mouemima@example.com','12345','gain'),
('Ali','ali@example.com','abc123','lose'),
('Sara','sara@example.com','pass123','gain');

CREATE TABLE Country (
  id_c INT PRIMARY KEY AUTO_INCREMENT,
  name_c VARCHAR(50),
  food_gain VARCHAR(50),
  food_lose VARCHAR(50),
  foodgain_picture VARCHAR(50),
  foodlose_picture VARCHAR(50)
);

INSERT INTO Country (name_c, food_gain, food_lose, foodgain_picture, foodlose_picture) VALUES
('Lebanon','Kibbeh','Tabbouleh','kibbeh.jpg','tabbouleh.jpg'),
('Italy','Pizza','Vegetable Soup','pizza.jpg','vegetable_soup.jpg'),
('France','Croissant','Ratatouille','croissant.jpg','ratatouille.jpg'),
('Mexico','Burrito','Ceviche','burrito.jpg','ceviche.jpg');